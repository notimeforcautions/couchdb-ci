<!-- SPDX-FileCopyrightText: © Fossology contributors

     SPDX-License-Identifier: GPL-2.0-only
-->
Introduction
--------------

Ninka is license identification tool that identifies the license(s)
under which a source file is made available.

This FOSSology plugin is a wrapper for the Ninka tool. 

Download
--------------

https://github.com/dmgerman/ninka