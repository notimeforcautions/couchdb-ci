/*
 SPDX-FileCopyrightText: © 2006-2009 Hewlett-Packard Development Company, L.P.

 SPDX-License-Identifier: GPL-2.0-only
*/

#ifndef _PARSE_H
#define _PARSE_H
#include "doctorBuffer_utils.h"
char *parseLicenses(char *filetext, int size, scanres_t *scp, int isML, int isPS);

#endif /* _PARSE_H */
