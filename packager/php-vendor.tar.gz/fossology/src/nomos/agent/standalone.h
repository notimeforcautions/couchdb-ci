/*
 SPDX-FileCopyrightText: © Fossology contributors

 SPDX-License-Identifier: GPL-2.0-only
*/

#ifndef _STANDALONE_H
#define _STANDALONE_H 1
#include <stdlib.h>
#include <stdbool.h>

typedef int PGconn;
typedef enum
{
    PGRES_EMPTY_QUERY = 0,      /** empty query string was executed */
    PGRES_COMMAND_OK,           /** a query command that doesn't return
                                 * anything was executed properly by the
                                 * backend */
    PGRES_TUPLES_OK,            /** a query command that returns tuples was
                                 * executed properly by the backend, PGresult
                                 * contains the result tuples */
    PGRES_COPY_OUT,             /** Copy Out data transfer in progress */
    PGRES_COPY_IN,              /** Copy In data transfer in progress */
    PGRES_BAD_RESPONSE,         /** an unexpected response was recv'd from the
                                 * backend */
    PGRES_NONFATAL_ERROR,       /** notice or warning message */
    PGRES_FATAL_ERROR           /** query failed */
} ExecStatusType;
#define PG_DIAG_SQLSTATE  0

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

typedef int PGresult;

#define PERM_WRITE 2
#define LOG_NOTICE(...) { \
            fprintf(stdout, "FATAL %s.%d: ", __FILE__, __LINE__); \
            fprintf(stdout, __VA_ARGS__); \
            fprintf(stdout, "\n"); \
            fflush(stdout); }
#define LOG_FATAL(...) { \
            fprintf(stdout, "FATAL %s.%d: ", __FILE__, __LINE__); \
            fprintf(stdout, __VA_ARGS__); \
            fprintf(stdout, "\n"); \
            fflush(stdout); }
#define LOG_ERROR(...) { \
            fprintf(stdout, "ERROR %s.%d: ", __FILE__, __LINE__); \
            fprintf(stdout, __VA_ARGS__); \
            fprintf(stdout, "\n"); \
            fflush(stdout); }
#define LOG_WARNING(...) { \
            fprintf(stdout, "WARNING %s.%d: ", __FILE__, __LINE__); \
            fprintf(stdout, __VA_ARGS__); \
            fprintf(stdout, "\n"); \
            fflush(stdout); }

extern void  fo_scheduler_heart(int i);
extern void  fo_scheduler_connect(int* argc, char** argv, PGconn** db_conn);
extern void  fo_scheduler_disconnect(int retcode);
extern char* fo_scheduler_next();
extern char* fo_scheduler_current();
extern int   fo_scheduler_userID();
extern void  fo_scheduler_set_special(int option, int value);
extern int   fo_scheduler_get_special(int option);
extern char* fo_sysconfig(const char* sectionname, const char* variablename);
extern int  fo_GetAgentKey   (PGconn *pgConn,const char *agent_name, long unused, const char *cpunused, const char *agent_desc);
extern int fo_WriteARS(PGconn *pgConn, int ars_pk, int upload_pk, int agent_pk,
                        const char *tableName, const char *ars_status, int ars_success);
extern PGconn *fo_dbconnect(char *DBConfFile, char **ErrorBuf);
extern int     fo_checkPQcommand(PGconn *pgConn, PGresult *result, char *sql, char *FileID, int LineNumb);
extern int     fo_checkPQresult(PGconn *pgConn, PGresult *result, char *sql, char *FileID, int LineNumb);
extern int     fo_tableExists(PGconn *pgConn, const char *tableName);
extern int GetUploadPerm(PGconn *pgConn, long UploadPk, int user_pk);
extern char * fo_RepMkPath (char *Type, char *Filename);


typedef struct {} fo_dbManager;
typedef struct {} fo_dbManager_PreparedStatement;

#define fo_dbManager_PrepareStamement(dbManager, name, query, ...) \
fo_dbManager_PrepareStamement_str(dbManager, \
  name, \
  query, \
  #__VA_ARGS__\
)


fo_dbManager* fo_dbManager_new(PGconn* dbConnection);
void fo_dbManager_free(fo_dbManager* dbManager);
fo_dbManager_PreparedStatement* fo_dbManager_PrepareStamement_str(fo_dbManager* dbManager, const char* name, const char* query, const char* paramtypes);
PGresult* fo_dbManager_ExecPrepared(fo_dbManager_PreparedStatement* preparedStatement, ...);

PGresult* getSelectedPFiles(PGconn* pgConn, int uploadPk, int agentPk, bool ignoreFilesWithMimeType);
PGresult* checkDuplicateReq(PGconn* pgConn, int upload_pk, int agentPk);


//ExecStatusType PQresultStatus(const PGresult *res);
extern int PQresultStatus(const PGresult *res);
extern char *PQresultErrorMessage(const PGresult *res);
extern char *PQresultErrorField(const PGresult *res, int fieldcode);
extern int  PQntuples(const PGresult *res);
extern PGresult *PQexec(PGconn *conn, const char *query);
extern void PQclear(PGresult *res);
extern char *PQgetvalue(const PGresult *res, int tup_num, int field_num);
extern size_t PQescapeStringConn(PGconn *conn,
                   char *to, const char *from, size_t length,
                   int *error);
extern void PQfinish(PGconn *conn);

#endif
