/*
 SPDX-FileCopyrightText: © 2006-2009 Hewlett-Packard Development Company, L.P.

 SPDX-License-Identifier: GPL-2.0-only
*/

#ifndef _LICENSES_H
#define _LICENSES_H

void licenseInit();
int ignoreFileForScan(char *s);
void licenseScan(list_t *l);

#endif /* _LICENSES_H */
