/***************************************************************
 * Project:
 *	  CPLD SlaveSerial Configuration via embedded microprocessor.
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 ****************************************************************/

